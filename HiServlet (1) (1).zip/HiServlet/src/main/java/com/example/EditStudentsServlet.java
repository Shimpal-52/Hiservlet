package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class EditStudentsServlet
 */
@WebServlet("/EditStudents")
public class EditStudentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditStudentsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");

	        PrintWriter out = response.getWriter();

	        String url = "jdbc:mysql://localhost:3306/uptec";
	        String username = "root";
	        String password = "Root@123";

	        String sql = "SELECT * FROM tblstu";

	        try {

	            Class.forName("com.mysql.cj.jdbc.Driver");

	            Connection con =
	                    DriverManager.getConnection(url, username, password);

	            PreparedStatement ps =
	                    con.prepareStatement(sql);

	            ResultSet rs = ps.executeQuery();

	            out.println("<html>");
	            out.println("<head>");
	            out.println("<title>Student List</title>");
	            out.println("</head>");

	            out.println("<body>");

	            out.println("<h2>All Students</h2>");

	            out.println("<table border='1' cellpadding='10'>");

	            out.println("<tr>");
	            out.println("<th>ID</th>");
	            out.println("<th>Name</th>");
	            out.println("<th>Age</th>");
	            out.println("<th>Address</th>");
	            out.println("<th>Action</th>");
	            out.println("</tr>");

	            while (rs.next()) {

	            	int id = rs.getInt("id");

	            	out.println("<tr>");

	            	out.println("<td>" + id + "</td>");
	            	out.println("<td>" + rs.getString("name") + "</td>");
	            	out.println("<td>" + rs.getInt("age") + "</td>");
	            	out.println("<td>" + rs.getString("address") + "</td>");

	            	out.println("<td>");
	            	out.println("<a href='updateStudent?id=" + id + "'>Edit</a>");
	            	out.println(" | ");

	            	out.println("<a href='DeleteStudent?id=" + id + "' "
	            	        + "onclick=\"return confirm('Are you sure you want to delete this student?');\">"
	            	        + "Delete</a>");
	            	out.println("</td>");

	            	out.println("</tr>");
	            }

	            out.println("</table>");

	            out.println("</body>");
	            out.println("</html>");

	            rs.close();
	            ps.close();
	            con.close();

	        } catch (Exception e) {

	            e.printStackTrace();

	            out.println("<h2>Error: " + e.getMessage() + "</h2>");
	        }
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
