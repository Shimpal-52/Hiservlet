package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class UpdatedStudentServlet
 */
@WebServlet("/UpdatedStudent")
public class UpdatedStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatedStudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");

	        PrintWriter out = response.getWriter();

	        int id = Integer.parseInt(request.getParameter("id"));
	        String name = request.getParameter("name");
	        int age = Integer.parseInt(request.getParameter("age"));
	        String address = request.getParameter("address");

	        String url = "jdbc:mysql://localhost:3306/uptec";
	        String username = "root";
	        String password = "Root@123";

	        String sql = "UPDATE tblstu SET name=?, age=?, address=? WHERE id=?";

	        try {

	            Class.forName("com.mysql.cj.jdbc.Driver");

	            Connection con =
	                    DriverManager.getConnection(url, username, password);

	            PreparedStatement ps =
	                    con.prepareStatement(sql);

	            ps.setString(1, name);
	            ps.setInt(2, age);
	            ps.setString(3, address);
	            ps.setInt(4, id);

	            int rows = ps.executeUpdate();

	            if (rows > 0) {

	                out.println("<h2>Student updated successfully!</h2>");

	                out.println("<a href='ViewStudents'>");
	                out.println("View All Students");
	                out.println("</a>");

	            } else {

	                out.println("<h2>Student not found.</h2>");
	            }

	            ps.close();
	            con.close();

	        } catch (Exception e) {

	            e.printStackTrace();

	            out.println("<h2>Error: " + e.getMessage() + "</h2>");
	        }
		doGet(request, response);
	}

}
