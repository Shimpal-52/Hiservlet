package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class updateStudentServlet
 */
@WebServlet("/updateStudent")
public class updateStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateStudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        int id = Integer.parseInt(request.getParameter("id"));

        String url = "jdbc:mysql://localhost:3306/uptec";
        String username = "root";
        String password = "Root@123";

        String sql = "SELECT * FROM tblstu WHERE id = ?";

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con =
                    DriverManager.getConnection(url, username, password);

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                out.println("<html>");
                out.println("<head>");
                out.println("<title>Edit Student</title>");
                out.println("</head>");

                out.println("<body>");

                out.println("<h2>Edit Student</h2>");

                out.println("<form action='UpdatedStudent' method='post'>");

                // Hidden ID
                out.println("<input type='hidden' name='id' value='"
                        + rs.getInt("id") + "'>");

                out.println("Name: ");
                out.println("<input type='text' name='name' value='"
                        + rs.getString("name") + "'>");
                out.println("<br><br>");

                out.println("Age: ");
                out.println("<input type='number' name='age' value='"
                        + rs.getInt("age") + "'>");
                out.println("<br><br>");

                out.println("Address: ");
                out.println("<textarea name='address'>"
                        + rs.getString("address")
                        + "</textarea>");
                out.println("<br><br>");

                out.println("<input type='submit' value='Update Student'>");

                out.println("</form>");

                out.println("</body>");
                out.println("</html>");
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        }
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
